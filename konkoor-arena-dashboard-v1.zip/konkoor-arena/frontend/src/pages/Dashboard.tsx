import DashboardLayout from '../components/dashboard/layout/DashboardLayout';

export default function Dashboard(){
 return <main className="min-h-screen px-6 py-10 bg-gray-50 dark:bg-[#080B12]"><div className="mx-auto max-w-7xl"><DashboardLayout/></div></main>;
}
