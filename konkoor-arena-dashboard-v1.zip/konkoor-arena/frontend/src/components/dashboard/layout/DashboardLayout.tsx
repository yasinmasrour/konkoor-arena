import { useState } from 'react';
import DashboardSidebar, { type DashboardSection } from './DashboardSidebar';
import DashboardHome from '../panels/DashboardHome';
import ProfilePanel from '../panels/ProfilePanel';
import ExamsPanel from '../panels/ExamsPanel';
import ArenaPanel from '../panels/ArenaPanel';
import SubscriptionPanel from '../panels/SubscriptionPanel';
import PaymentsPanel from '../panels/PaymentsPanel';
import WalletPanel from '../panels/WalletPanel';
import StrategyPanel from '../panels/StrategyPanel';

export default function DashboardLayout(){
 const [active,setActive]=useState<DashboardSection>('home');
 const panels:any={home:DashboardHome,profile:ProfilePanel,exams:ExamsPanel,arena:ArenaPanel,subscription:SubscriptionPanel,payments:PaymentsPanel,wallet:WalletPanel,strategy:StrategyPanel,notifications:DashboardHome,settings:ProfilePanel};
 const Panel=panels[active];
 return <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
  <DashboardSidebar active={active} onChange={setActive}/>
  <section><Panel/></section>
 </div>;
}
