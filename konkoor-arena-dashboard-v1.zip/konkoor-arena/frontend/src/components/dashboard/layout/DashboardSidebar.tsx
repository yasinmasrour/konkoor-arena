import { LayoutDashboard, User, FileText, Swords, CreditCard, Wallet, CalendarDays, Bell, Settings } from 'lucide-react';

export type DashboardSection = 'home'|'profile'|'exams'|'arena'|'subscription'|'payments'|'wallet'|'strategy'|'notifications'|'settings';

const items = [
 {id:'home',label:'داشبورد',icon:LayoutDashboard},
 {id:'profile',label:'پروفایل',icon:User},
 {id:'exams',label:'آزمون‌ها',icon:FileText},
 {id:'arena',label:'آرنا',icon:Swords},
 {id:'subscription',label:'وضعیت اشتراک',icon:CreditCard},
 {id:'payments',label:'سوابق پرداخت',icon:CreditCard},
 {id:'wallet',label:'کیف پول',icon:Wallet},
 {id:'strategy',label:'برنامه راهبردی',icon:CalendarDays},
 {id:'notifications',label:'اعلان‌ها',icon:Bell},
 {id:'settings',label:'تنظیمات',icon:Settings},
] as const;

export default function DashboardSidebar({active,onChange}:{active:DashboardSection;onChange:(s:DashboardSection)=>void}){
 return <aside className="rounded-3xl border border-slate-200/70 bg-white/70 p-4 backdrop-blur-xl dark:border-white/10 dark:bg-white/5">
  <nav className="space-y-2">
   {items.map(item=>{const Icon=item.icon; const selected=active===item.id; return <button key={item.id} onClick={()=>onChange(item.id)} className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-right transition ${selected?'bg-[var(--griffin-gold)]/15 text-[var(--griffin-gold)]':'text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/10'}`}><Icon className="h-5 w-5"/><span className="font-semibold">{item.label}</span></button>})}
  </nav>
 </aside>;
}
