const StrategyPanel = () => <div className="rounded-3xl border border-slate-200/70 bg-white/70 p-6 backdrop-blur-xl dark:border-white/10 dark:bg-white/5"><h2 className="text-xl font-bold dark:text-white">Strategy</h2><p className="mt-2 text-slate-500 dark:text-slate-400">این بخش آماده توسعه است.</p></div>;
export default StrategyPanel;
