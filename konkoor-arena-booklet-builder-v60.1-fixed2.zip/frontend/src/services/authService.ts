import api from "../api/axios";

interface LoginData {
  email: string;

  password: string;
}

interface RegisterData {
  firstName: string;

  lastName: string;

  email: string;

  password: string;
}

export const loginUser = async (data: LoginData) => {
  const response = await api.post("/auth/login", data);

  return response.data;
};

export const registerUser = async (data: RegisterData) => {
  const response = await api.post("/auth/register", data);

  return response.data;
};
