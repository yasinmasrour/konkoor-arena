import { Outlet } from "react-router-dom";
import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";

const MainLayout = () => {
  return (
    <div
      className="
        min-h-screen
        flex
        flex-col
        bg-[var(--griffin-bg)]
        dark:bg-[var(--griffin-dark)]
      "
    >
      <Navbar />

      <main
        className="
          flex-1
        "
      >
        <Outlet />
      </main>

      <Footer />
    </div>
  );
};

export default MainLayout;
